from setuptools import setup

setup(
    name="flow2ml",
    version="1.0.1",
    description="flow2ml",
    packages=['flow2ml'],
    zip_safe=False
)